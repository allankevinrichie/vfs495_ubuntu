
resume_FPS() {
    # Signal the vcsFPService about the resume
        pkill -SIGUSR2 vcsFPService
}
case "$1" in
        thaw|resume)
                resume_FPS
                ;;
        *)
                ;;
esac

exit $?

