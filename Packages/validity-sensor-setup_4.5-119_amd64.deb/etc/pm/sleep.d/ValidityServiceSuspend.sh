#!/bin/bash

. /usr/lib/pm-utils/functions

suspend_FPS() {
    # Signal the vcsFPService about the suspend/hiberante
	echo " Sending Suspend Event"
	pkill -SIGUSR1 vcsFPService
}

case "$1" in
	hibernate|suspend)
		suspend_FPS
		;;
	*)
		;;
esac

exit $?
